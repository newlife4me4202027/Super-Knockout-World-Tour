extends Node3D

const FIGHTERS := [
    {"name":"BRUNO BRICKWALL","style":"POWERHOUSE","skin":Color("#b87550"),"gear":Color("#b92e28"),"glove":Color("#e33b32"),"hp":125,"power":1.35,"speed":0.72},
    {"name":"EL TORNADO","style":"SPEEDSTER","skin":Color("#a96f4b"),"gear":Color("#278b45"),"glove":Color("#45cf62"),"hp":90,"power":0.85,"speed":1.45},
    {"name":"TANK TANAKA","style":"DEFENDER","skin":Color("#c58b65"),"gear":Color("#225b83"),"glove":Color("#258ac2"),"hp":145,"power":0.95,"speed":0.65},
    {"name":"VIPER VOSS","style":"TECHNICIAN","skin":Color("#e0b08a"),"gear":Color("#60358d"),"glove":Color("#9b59d0"),"hp":100,"power":1.05,"speed":1.15},
    {"name":"MR. DYNAMO","style":"AGGRESSOR","skin":Color("#8e5739"),"gear":Color("#8e641b"),"glove":Color("#e5b52c"),"hp":110,"power":1.2,"speed":1.05},
    {"name":"SIREN","style":"SHOWBOAT","skin":Color("#e0b28f"),"gear":Color("#a52d70"),"glove":Color("#ec70b2"),"hp":95,"power":0.95,"speed":1.25},
    {"name":"GRIZZLY","style":"BRAWLER","skin":Color("#a66d4c"),"gear":Color("#41672d"),"glove":Color("#6eaa40"),"hp":135,"power":1.25,"speed":0.82},
    {"name":"KAISER KLAW","style":"FINAL BOSS","skin":Color("#b8a18d"),"gear":Color("#292d38"),"glove":Color("#d94332"),"hp":165,"power":1.5,"speed":1.1}
]

var opponent_index := 0
var player_hp := 100.0
var player_max_hp := 100.0
var enemy_hp := 100.0
var enemy_max_hp := 100.0
var stamina := 100.0
var guarding := false
var dodging := false
var enemy_windup := false
var enemy_attack_timer := 1.8
var windup_timer := 0.0
var dodge_timer := 0.0
var player_hit_timer := 0.0
var enemy_hit_timer := 0.0
var bout_over := false
var wins := 0
var player_model: Node3D
var enemy_model: Node3D
var player_root: Node3D
var enemy_root: Node3D
var ui: CanvasLayer
var status_label: Label
var player_bar: ProgressBar
var enemy_bar: ProgressBar
var stamina_bar: ProgressBar
var title_label: Label
var opponent_label: Label
var buttons: Array[Button] = []

func _ready() -> void:
    _make_world()
    _make_hud()
    _load_fight(0)

func _process(delta: float) -> void:
    stamina = minf(100.0, stamina + delta * (5.0 if not guarding else -7.0))
    if dodge_timer > 0.0:
        dodge_timer -= delta
        if dodge_timer <= 0.0:
            dodging = false
            player_root.position.x = 0.0
    if player_hit_timer > 0.0:
        player_hit_timer -= delta
    if enemy_hit_timer > 0.0:
        enemy_hit_timer -= delta
    if not bout_over:
        enemy_attack_timer -= delta
        if enemy_attack_timer <= 0.0 and not enemy_windup:
            enemy_windup = true
            windup_timer = 0.85
            status_label.text = FIGHTERS[opponent_index].name + " IS WINDING UP!"
        if enemy_windup:
            windup_timer -= delta
            if windup_timer <= 0.0:
                _enemy_attack()
    _refresh_hud()
    if player_model:
        var idle := sin(Time.get_ticks_msec() * 0.003) * 0.018
        player_model.position.y = idle
        var left_arm := player_model.get_node_or_null("ArmPivotL") as Node3D
        var right_arm := player_model.get_node_or_null("ArmPivotR") as Node3D
        if left_arm: left_arm.rotation.x = sin(Time.get_ticks_msec() * 0.004) * 0.025
        if right_arm: right_arm.rotation.x = -sin(Time.get_ticks_msec() * 0.004) * 0.025
    if enemy_model:
        enemy_model.position.y = sin(Time.get_ticks_msec() * 0.0035 + 1.2) * 0.02
    if player_model and player_hit_timer > 0.0:
        player_model.rotation.z = sin(Time.get_ticks_msec() * 0.04) * 0.12
    elif player_model:
        player_model.rotation.z = lerpf(player_model.rotation.z, 0.0, delta * 8.0)
    if enemy_model and enemy_hit_timer > 0.0:
        enemy_model.rotation.z = -0.16
    elif enemy_model:
        enemy_model.rotation.z = lerpf(enemy_model.rotation.z, 0.0, delta * 7.0)

func _mat(color: Color, metallic := 0.0, roughness := 0.62) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = roughness
    return m

func _mesh(parent: Node3D, mesh: Mesh, material: Material, pos: Vector3, scale := Vector3.ONE) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.material_override = material
    node.position = pos
    node.scale = scale
    parent.add_child(node)
    return node

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    return _mesh(parent, mesh, _mat(color), pos)

func _sphere(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    mesh.radial_segments = 24
    mesh.rings = 12
    return _mesh(parent, mesh, _mat(color), pos, size)

func _capsule(parent: Node3D, pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = height
    mesh.radial_segments = 20
    return _mesh(parent, mesh, _mat(color), pos)

func _make_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#101a2d")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#b7c9e8")
    env.ambient_light_energy = 0.55
    world_env.environment = env
    add_child(world_env)

    var camera := Camera3D.new()
    camera.position = Vector3(0, 5.2, 12.8)
    camera.rotation_degrees = Vector3(-16, 0, 0)
    camera.fov = 48
    add_child(camera)
    camera.current = true

    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-48, -25, 0)
    key.light_energy = 1.45
    key.shadow_enabled = true
    add_child(key)
    var fill := OmniLight3D.new()
    fill.position = Vector3(-5, 5, 3)
    fill.light_color = Color("#5f9dff")
    fill.light_energy = 2.0
    fill.omni_range = 18
    add_child(fill)
    var rim := OmniLight3D.new()
    rim.position = Vector3(5, 5, -5)
    rim.light_color = Color("#ffb14a")
    rim.light_energy = 2.4
    rim.omni_range = 16
    add_child(rim)

    _box(self, Vector3(0, -0.42, 0), Vector3(13, 0.55, 11), Color("#202b3d"))
    _box(self, Vector3(0, -0.08, 0), Vector3(8.2, 0.22, 7.5), Color("#33445b"))
    for z in [-3.55, 3.55]:
        for y in [0.45, 1.1, 1.75]:
            _box(self, Vector3(0, y, z), Vector3(8.5, 0.055, 0.055), Color("#e6e8ec"))
    for x in [-4.15, 4.15]:
        for y in [0.45, 1.1, 1.75]:
            _box(self, Vector3(x, y, 0), Vector3(0.055, 0.055, 7.1), Color("#d6dce8"))
    for x in [-4.15, 4.15]:
        for z in [-3.55, 3.55]:
            _box(self, Vector3(x, 0.8, z), Vector3(0.28, 2.0, 0.28), Color("#a83d43"))
    # Arena fascia and distant audience silhouettes
    _box(self, Vector3(0, 2.8, -5.2), Vector3(13, 2.8, 0.3), Color("#101827"))
    for row in range(3):
        for i in range(25):
            var x := -6.0 + i * 0.5
            var z := -5.0 - row * 0.48
            var hue := [Color("#b64b50"), Color("#d6a45d"), Color("#536e9c"), Color("#8998a9")][(i + row) % 4]
            _sphere(self, Vector3(x, 2.1 + row * 0.36, z), Vector3(0.22, 0.28, 0.2), hue)

func _build_boxer(data: Dictionary, is_player: bool) -> Node3D:
    var rig := Node3D.new()
    var skin: Color = data.skin
    var gear: Color = data.gear
    var glove: Color = data.glove
    # Torso layers create a more athletic silhouette than a single capsule.
    _capsule(rig, Vector3(0, 1.10, 0), 0.46, 1.42, skin)
    _sphere(rig, Vector3(0, 1.83, 0), Vector3(1.22, 0.78, 0.64), skin)
    _sphere(rig, Vector3(0, 2.10, 0.08), Vector3(1.28, 0.48, 0.62), skin)
    _capsule(rig, Vector3(0, 2.48, 0), 0.16, 0.38, skin)
    _sphere(rig, Vector3(0, 2.88, 0), Vector3(0.64, 0.76, 0.56), skin)
    # Hair/cap silhouette and facial planes.
    _sphere(rig, Vector3(0, 3.19, -0.015), Vector3(0.66, 0.27, 0.57), gear.darkened(0.35))
    _sphere(rig, Vector3(0, 2.72, 0.255), Vector3(0.25, 0.12, 0.12), skin.darkened(0.12))
    for side in [-1.0, 1.0]:
        _sphere(rig, Vector3(side * 0.145, 2.91, 0.245), Vector3(0.095, 0.075, 0.045), Color("#f4e8d8"))
        _sphere(rig, Vector3(side * 0.145, 2.91, 0.282), Vector3(0.035, 0.052, 0.022), Color("#17151a"))
        _box(rig, Vector3(side * 0.15, 3.025, 0.245), Vector3(0.19, 0.045, 0.035), gear.darkened(0.5))
        _sphere(rig, Vector3(side * 0.34, 2.77, 0.13), Vector3(0.16, 0.2, 0.13), skin.darkened(0.08))
    _box(rig, Vector3(0, 2.59, 0.27), Vector3(0.2, 0.035, 0.025), Color("#512b28"))
    # Shorts, waistband, side piping, knee pads and boots.
    _box(rig, Vector3(0, 0.53, 0), Vector3(1.03, 0.53, 0.68), gear)
    _box(rig, Vector3(0, 0.81, 0.015), Vector3(1.08, 0.09, 0.7), Color("#e6c36e"))
    for side in [-1.0, 1.0]:
        _box(rig, Vector3(side * 0.47, 0.53, 0.02), Vector3(0.045, 0.45, 0.69), gear.lightened(0.28))
        _capsule(rig, Vector3(side * 0.26, 0.04, 0), 0.17, 0.76, skin)
        _box(rig, Vector3(side * 0.26, -0.27, 0.13), Vector3(0.4, 0.2, 0.61), Color("#171d29"))
        _box(rig, Vector3(side * 0.26, -0.16, 0.4), Vector3(0.34, 0.045, 0.05), Color("#e9e9e9"))
        _sphere(rig, Vector3(side * 0.48, 2.05, 0), Vector3(0.48, 0.48, 0.54), skin)
    # Shoulder-mounted arm pivots. Animation code can rotate these independently.
    for side in [-1.0, 1.0]:
        var arm_pivot := Node3D.new()
        arm_pivot.name = "ArmPivotL" if side < 0 else "ArmPivotR"
        arm_pivot.position = Vector3(side * 0.53, 2.05, 0.03)
        rig.add_child(arm_pivot)
        _capsule(arm_pivot, Vector3(side * 0.10, -0.32, 0.08), 0.19, 0.72, skin)
        _sphere(arm_pivot, Vector3(side * 0.14, -0.65, 0.28), Vector3(0.37, 0.36, 0.34), glove)
        _sphere(arm_pivot, Vector3(side * 0.14, -0.68, 0.44), Vector3(0.26, 0.1, 0.1), Color("#f4d7c5"))
        _box(arm_pivot, Vector3(side * 0.14, -0.43, 0.26), Vector3(0.3, 0.12, 0.14), Color("#f1e5d5"))
    return rig

func _make_hud() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(root)
    title_label = Label.new()
    title_label.text = "SUPER KNOCKOUT!!  •  WORLD TOUR"
    title_label.add_theme_font_size_override("font_size", 24)
    title_label.add_theme_color_override("font_color", Color("#ffc34d"))
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.anchor_left = 0.15
    title_label.anchor_right = 0.85
    title_label.offset_top = 8
    title_label.offset_bottom = 42
    root.add_child(title_label)
    opponent_label = Label.new()
    opponent_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    opponent_label.anchor_left = 0.25
    opponent_label.anchor_right = 0.75
    opponent_label.offset_top = 48
    opponent_label.offset_bottom = 76
    opponent_label.add_theme_font_size_override("font_size", 17)
    root.add_child(opponent_label)

    player_bar = _add_bar(root, Rect2(18, 48, 250, 20), Color("#38c66b"))
    enemy_bar = _add_bar(root, Rect2(0, 48, 250, 20), Color("#ed5747"))
    enemy_bar.anchor_left = 1.0
    enemy_bar.anchor_right = 1.0
    enemy_bar.offset_left = -268
    enemy_bar.offset_right = -18
    stamina_bar = _add_bar(root, Rect2(18, 76, 250, 12), Color("#e6b642"))
    status_label = Label.new()
    status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status_label.anchor_left = 0.2
    status_label.anchor_right = 0.8
    status_label.anchor_top = 0.78
    status_label.anchor_bottom = 0.78
    status_label.offset_top = -35
    status_label.offset_bottom = 0
    status_label.add_theme_font_size_override("font_size", 18)
    status_label.add_theme_color_override("font_color", Color("#ffe28a"))
    root.add_child(status_label)

    _add_touch_button(root, "DODGE ◀", 0.02, 0.78, 0.16, 0.1, "left")
    _add_touch_button(root, "DUCK", 0.19, 0.78, 0.14, 0.1, "duck")
    _add_touch_button(root, "DODGE ▶", 0.34, 0.78, 0.16, 0.1, "right")
    _add_touch_button(root, "JAB", 0.57, 0.78, 0.12, 0.1, "jab")
    _add_touch_button(root, "HOOK", 0.70, 0.78, 0.13, 0.1, "hook")
    _add_touch_button(root, "UPPERCUT", 0.84, 0.78, 0.14, 0.1, "upper")
    _add_touch_button(root, "BODY", 0.57, 0.90, 0.12, 0.08, "body")
    _add_touch_button(root, "BLOCK", 0.70, 0.90, 0.13, 0.08, "block")
    _add_touch_button(root, "NEXT FIGHT", 0.84, 0.90, 0.14, 0.08, "next")

func _add_bar(parent: Control, rect: Rect2, color: Color) -> ProgressBar:
    var bar := ProgressBar.new()
    bar.position = rect.position
    bar.size = rect.size
    bar.min_value = 0
    bar.max_value = 100
    bar.value = 100
    bar.show_percentage = false
    var fill := StyleBoxFlat.new()
    fill.bg_color = color
    bar.add_theme_stylebox_override("fill", fill)
    var bg := StyleBoxFlat.new()
    bg.bg_color = Color("#202a3b")
    bar.add_theme_stylebox_override("background", bg)
    parent.add_child(bar)
    return bar

func _add_touch_button(parent: Control, caption: String, left: float, top: float, width: float, height: float, action: String) -> void:
    var b := Button.new()
    b.text = caption
    b.anchor_left = left
    b.anchor_right = left + width
    b.anchor_top = top
    b.anchor_bottom = top + height
    b.add_theme_font_size_override("font_size", 15)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color("#1b2d49dd")
    normal.border_width_left = 2
    normal.border_width_right = 2
    normal.border_width_top = 2
    normal.border_width_bottom = 2
    normal.border_color = Color("#8da9cf")
    normal.corner_radius_top_left = 10
    normal.corner_radius_top_right = 10
    normal.corner_radius_bottom_left = 10
    normal.corner_radius_bottom_right = 10
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", normal)
    b.pressed.connect(func(): _action(action))
    parent.add_child(b)
    buttons.append(b)

func _load_fight(index: int) -> void:
    opponent_index = clampi(index, 0, FIGHTERS.size() - 1)
    if is_instance_valid(player_root):
        player_root.queue_free()
    if is_instance_valid(enemy_root):
        enemy_root.queue_free()
    var data: Dictionary = FIGHTERS[opponent_index]
    player_root = Node3D.new()
    add_child(player_root)
    player_root.position = Vector3(0, 0.0, 3.15)
    player_model = _build_boxer({"skin":Color("#bd805d"),"gear":Color("#17477f"),"glove":Color("#247fc2")}, true)
    player_model.position = Vector3(0, 0, 0)
    player_model.get_parent().remove_child(player_model)
    player_root.add_child(player_model)
    enemy_root = Node3D.new()
    add_child(enemy_root)
    enemy_root.position = Vector3(0, 0.0, -1.95)
    enemy_model = _build_boxer(data, false)
    enemy_model.get_parent().remove_child(enemy_model)
    enemy_root.add_child(enemy_model)
    player_max_hp = 100.0
    enemy_max_hp = float(data.hp)
    player_hp = player_max_hp
    enemy_hp = enemy_max_hp
    stamina = 100.0
    bout_over = false
    enemy_windup = false
    enemy_attack_timer = 1.7
    opponent_label.text = "CHAMPIONSHIP  %d / 8     •     %s — %s" % [opponent_index + 1, data.name, data.style]
    status_label.text = "FIGHT! Read the opponent's tell, dodge, then counter."
    _refresh_hud()

func _action(action: String) -> void:
    if action == "next":
        if bout_over and enemy_hp <= 0.0:
            if opponent_index < 7:
                wins += 1
                _load_fight(opponent_index + 1)
            else:
                status_label.text = "WORLD CHAMPION! YOU WON THE WORLD TOUR!"
        elif bout_over:
            _load_fight(opponent_index)
        return
    if bout_over:
        return
    match action:
        "left":
            _dodge(-1.0)
        "right":
            _dodge(1.0)
        "duck":
            _dodge(0.0)
        "block":
            guarding = not guarding
            status_label.text = "GUARD UP" if guarding else "GUARD DOWN"
        "jab":
            _punch(7.0, 5.0, "JAB")
        "hook":
            _punch(13.0, 12.0, "POWER HOOK")
        "upper":
            _punch(20.0, 17.0, "RISING DRAGON")
        "body":
            _punch(11.0, 9.0, "BODY SHOT")

func _dodge(direction: float) -> void:
    dodging = true
    dodge_timer = 0.55
    player_root.position.x = direction * 0.85
    if direction == 0.0:
        status_label.text = "DUCK! HIGH PUNCH AVOIDED"
    else:
        status_label.text = "SLIP! STAY IN THE BOXING LANE"

func _punch(damage: float, cost: float, move_name: String) -> void:
    if stamina < cost:
        status_label.text = "TOO TIRED — RECOVER STAMINA"
        return
    stamina -= cost
    player_hit_timer = 0.22
    var multiplier := 1.0
    if enemy_windup:
        multiplier = 1.8
        status_label.text = "PERFECT COUNTER! " + move_name
    else:
        status_label.text = move_name + "!"
    enemy_hp = maxf(0.0, enemy_hp - damage * multiplier)
    enemy_hit_timer = 0.25
    _play_sfx("punch_heavy.wav" if damage >= 12.0 else "punch_light.wav")
    _impact_flash(enemy_root.global_position + Vector3(0, 1.8, 0.8), Color("#fff0a0"))
    if enemy_hp <= 0.0:
        bout_over = true
        status_label.text = "KNOCKOUT! PRESS NEXT FIGHT TO CONTINUE"
        _play_sfx("bell_round.wav")
    _refresh_hud()

func _enemy_attack() -> void:
    enemy_windup = false
    enemy_attack_timer = maxf(1.05, 2.8 - float(opponent_index) * 0.16) / float(FIGHTERS[opponent_index].speed)
    if dodging:
        _play_sfx("block.wav")
        status_label.text = "CLEAN DODGE! COUNTER NOW!"
        return
    var data: Dictionary = FIGHTERS[opponent_index]
    var damage := 11.0 * float(data.power)
    if guarding:
        _play_sfx("block.wav")
        damage *= 0.28
        stamina = maxf(0.0, stamina - 8.0)
        status_label.text = "BLOCKED! GUARD ABSORBED THE HIT"
    else:
        status_label.text = "YOU GOT CAUGHT BY " + str(data.name) + "!"
    player_hp = maxf(0.0, player_hp - damage)
    player_hit_timer = 0.25
    if player_hp <= 0.0:
        bout_over = true
        status_label.text = "KNOCKDOWN! PRESS NEXT FIGHT TO RETRY"
    _refresh_hud()


func _impact_flash(at: Vector3, tint: Color) -> void:
    var flash := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.42
    sphere.height = 0.84
    flash.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.emission_enabled = true
    mat.emission = tint
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    flash.material_override = mat
    flash.position = at
    add_child(flash)
    var tween := create_tween()
    tween.tween_property(flash, "scale", Vector3(1.8, 1.8, 1.8), 0.12)
    tween.parallel().tween_property(flash, "transparency", 1.0, 0.12)
    tween.tween_callback(flash.queue_free)

func _play_sfx(file_name: String) -> void:
    var stream := load("res://assets/" + file_name) as AudioStream
    if stream == null:
        return
    var player := AudioStreamPlayer.new()
    player.stream = stream
    player.volume_db = -4.0
    add_child(player)
    player.finished.connect(player.queue_free)
    player.play()

func _refresh_hud() -> void:
    if is_instance_valid(player_bar):
        player_bar.max_value = player_max_hp
        player_bar.value = player_hp
        enemy_bar.max_value = enemy_max_hp
        enemy_bar.value = enemy_hp
        stamina_bar.value = stamina
