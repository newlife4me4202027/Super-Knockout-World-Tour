extends Node3D

const FIGHTERS = [
    {"name":"Bruno Brickwall","style":"Powerhouse","color":Color("#d94732"),"skin":Color("#a96a4a"),"shorts":Color("#8c2026"),"hp":125,"power":1.35},
    {"name":"El Tornado","style":"Speedster","color":Color("#36b64c"),"skin":Color("#b77b55"),"shorts":Color("#18763b"),"hp":90,"power":0.85},
    {"name":"Tank Tanaka","style":"Defender","color":Color("#2789c4"),"skin":Color("#b77d5b"),"shorts":Color("#164c76"),"hp":145,"power":1.0},
    {"name":"Viper Voss","style":"Technician","color":Color("#9a55c9"),"skin":Color("#d0a17c"),"shorts":Color("#542779"),"hp":100,"power":1.0},
    {"name":"Mr. Dynamo","style":"Aggressor","color":Color("#e4ae28"),"skin":Color("#85543c"),"shorts":Color("#9a6815"),"hp":115,"power":1.2},
    {"name":"Siren","style":"Showboat","color":Color("#df65a5"),"skin":Color("#e0b18f"),"shorts":Color("#9b326d"),"hp":95,"power":0.95},
    {"name":"Grizzly","style":"Brawler","color":Color("#659d3d"),"skin":Color("#a77553"),"shorts":Color("#365b29"),"hp":135,"power":1.15},
    {"name":"Kaiser Klaw","style":"Final Boss","color":Color("#9c3030"),"skin":Color("#a98c7a"),"shorts":Color("#33323b"),"hp":170,"power":1.4}
]

var selected := 0
var player_hp := 100.0
var enemy_hp := 100.0
var stamina := 100.0
var player_node: Node3D
var enemy_node: Node3D
var ui: CanvasLayer
var status_label: Label
var player_bar: ProgressBar
var enemy_bar: ProgressBar
var stamina_bar: ProgressBar
var busy := false
var blocking := false
var dodging := false
var enemy_timer := 1.8
var tell_timer := 0.0
var enemy_windup := false
var round_over := false
var championship_wins := 0
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    _build_arena()
    _build_camera()
    _build_ui()
    _spawn_fighters()
    _refresh_ui()
    _say("Choose your opponent. Tap FIGHT to start the bout.")

func _build_camera() -> void:
    var camera := Camera3D.new()
    camera.projection = Camera3D.PROJECTION_ORTHOGONAL
    camera.size = 12.5
    camera.position = Vector3(0, 0, 19)
    camera.current = true
    add_child(camera)

func _mat(color: Color, metallic := 0.0, roughness := 0.72) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = roughness
    return m

func _mesh(parent: Node3D, mesh: Mesh, material: Material, pos: Vector3, scale := Vector3.ONE) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.mesh = mesh
    n.material_override = material
    n.position = pos
    n.scale = scale
    parent.add_child(n)
    return n

func _build_arena() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#111a2b")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#8292b1")
    env.ambient_light_energy = 0.55
    world_env.environment = env
    add_child(world_env)

    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-35, -25, 0)
    key.light_energy = 1.35
    key.shadow_enabled = true
    add_child(key)

    var fill := OmniLight3D.new()
    fill.position = Vector3(0, 4, 7)
    fill.light_color = Color("#8abaff")
    fill.light_energy = 1.2
    fill.omni_range = 20
    add_child(fill)

    var floor := _mesh(self, PlaneMesh.new(), _mat(Color("#17243a")), Vector3(0, 0, -1))
    floor.scale = Vector3(18, 11, 1)

    # Ring mat, ropes and turnbuckles.
    var ring := _mesh(self, BoxMesh.new(), _mat(Color("#243c5a")), Vector3(0, 0, 0))
    ring.scale = Vector3(10.5, 7.1, 0.35)
    for y in [-3.35, -2.85, 2.85, 3.35]:
        var rope := _mesh(self, BoxMesh.new(), _mat(Color("#e5e6e8")), Vector3(0, y, 0.35))
        rope.scale = Vector3(10.4, 0.055, 0.055)
    for x in [-5.15, 5.15]:
        for y in [-3.35, 3.35]:
            var post := _mesh(self, CylinderMesh.new(), _mat(Color("#b63d40"), 0.2), Vector3(x, y, 0.2))
            post.scale = Vector3(0.18, 0.65, 0.18)
    # Crowd silhouettes and arena lights.
    for i in range(90):
        var crowd := _mesh(self, SphereMesh.new(), _mat([Color("#8d5360"),Color("#526f91"),Color("#c28b45"),Color("#536f59")][i % 4]), Vector3(-8.2 + float(i % 30) * 0.56, 4.1 + float(i / 30) * 0.48, -1.5))
        crowd.scale = Vector3(0.12, 0.16, 0.1)

func _fighter_model(data: Dictionary, is_player: bool) -> Node3D:
    var root := Node3D.new()
    add_child(root)
    var skin := _mat(data.skin)
    var trunks := _mat(data.shorts, 0.05)
    var glove := _mat(data.color, 0.12, 0.42)
    var dark := _mat(data.skin.darkened(0.25))
    # Broad athletic torso, neck and head.
    var torso := CapsuleMesh.new()
    torso.radius = 0.72 if not is_player else 0.78
    torso.height = 2.05
    _mesh(root, torso, skin, Vector3(0, 0.05, 0), Vector3(1.15, 1.0, 0.78))
    var shorts := CylinderMesh.new()
    shorts.top_radius = 0.78
    shorts.bottom_radius = 0.82
    shorts.height = 0.65
    _mesh(root, shorts, trunks, Vector3(0, -1.05, 0), Vector3(1.1, 1, 0.8))
    var head := SphereMesh.new()
    _mesh(root, head, skin, Vector3(0, 1.55, 0), Vector3(0.63, 0.78, 0.58))
    var hair := SphereMesh.new()
    _mesh(root, hair, dark, Vector3(0, 2.0, -0.02), Vector3(0.64, 0.34, 0.6))
    # Arms and oversized gloves are separate parts for readable arcade silhouettes.
    for side in [-1, 1]:
        var arm := CapsuleMesh.new()
        arm.radius = 0.24
        arm.height = 1.1
        var arm_node := _mesh(root, arm, skin, Vector3(side * 0.95, 0.25, 0.1), Vector3(1, 1.0, 1))
        arm_node.rotation.z = deg_to_rad(float(side) * -25)
        var fist := SphereMesh.new()
        _mesh(root, fist, glove, Vector3(side * 0.93, 0.82, 0.7), Vector3(0.48, 0.46, 0.43))
        var leg := CapsuleMesh.new()
        leg.radius = 0.24
        leg.height = 0.95
        _mesh(root, leg, skin, Vector3(side * 0.39, -1.85, 0), Vector3(1, 1, 0.9))
    # Facial features.
    for side in [-1, 1]:
        var eye := SphereMesh.new()
        _mesh(root, eye, _mat(Color("#f4eadc")), Vector3(side * 0.22, 1.62, 0.5), Vector3(0.09, 0.075, 0.045))
    return root

func _spawn_fighters() -> void:
    if is_instance_valid(player_node): player_node.queue_free()
    if is_instance_valid(enemy_node): enemy_node.queue_free()
    var player_data: Dictionary = {"skin":Color("#c68d68"),"shorts":Color("#183d79"),"color":Color("#238bd1")}
    player_node = _fighter_model(player_data, true)
    player_node.position = Vector3(0, -2.25, 1.8)
    player_node.rotation.y = PI
    enemy_node = _fighter_model(FIGHTERS[selected], false)
    enemy_node.position = Vector3(0, 2.15, 0.8)
    player_hp = 100.0
    enemy_hp = float(FIGHTERS[selected].hp)
    stamina = 100.0
    round_over = false
    enemy_timer = 1.5
    _refresh_ui()

func _build_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(root)

    var top := HBoxContainer.new()
    top.anchor_left = 0.04
    top.anchor_right = 0.96
    top.offset_top = 10
    top.offset_bottom = 78
    root.add_child(top)
    var pbox := VBoxContainer.new()
    pbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(pbox)
    var plabel := Label.new()
    plabel.text = "YOU · CONTENDER"
    pbox.add_child(plabel)
    player_bar = ProgressBar.new()
    player_bar.max_value = 100
    player_bar.show_percentage = false
    pbox.add_child(player_bar)
    var center := Label.new()
    center.text = "WORLD TOUR  ·  ROUND 1"
    center.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    center.custom_minimum_size.x = 260
    top.add_child(center)
    var ebox := VBoxContainer.new()
    ebox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(ebox)
    var elabel := Label.new()
    elabel.name = "EnemyLabel"
    elabel.text = FIGHTERS[selected].name.to_upper()
    elabel.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    ebox.add_child(elabel)
    enemy_bar = ProgressBar.new()
    enemy_bar.max_value = 170
    enemy_bar.show_percentage = false
    ebox.add_child(enemy_bar)

    status_label = Label.new()
    status_label.anchor_left = 0.15
    status_label.anchor_right = 0.85
    status_label.anchor_top = 0.13
    status_label.anchor_bottom = 0.2
    status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status_label.add_theme_font_size_override("font_size", 22)
    root.add_child(status_label)

    stamina_bar = ProgressBar.new()
    stamina_bar.anchor_left = 0.35
    stamina_bar.anchor_right = 0.65
    stamina_bar.anchor_top = 0.88
    stamina_bar.anchor_bottom = 0.92
    stamina_bar.max_value = 100
    stamina_bar.show_percentage = false
    root.add_child(stamina_bar)

    var controls := GridContainer.new()
    controls.columns = 4
    controls.anchor_left = 0.08
    controls.anchor_right = 0.92
    controls.anchor_top = 0.925
    controls.anchor_bottom = 0.995
    controls.add_theme_constant_override("h_separation", 8)
    controls.add_theme_constant_override("v_separation", 4)
    root.add_child(controls)
    _add_button(controls, "JAB", _jab)
    _add_button(controls, "HOOK", _hook)
    _add_button(controls, "UPPERCUT", _uppercut)
    _add_button(controls, "BODY", _body)
    _add_button(controls, "DODGE ◀", func(): _dodge(-1))
    _add_button(controls, "DUCK", _duck)
    _add_button(controls, "DODGE ▶", func(): _dodge(1))
    _add_button(controls, "BLOCK", func(): blocking = true)
    _add_button(controls, "FIGHT / NEXT", _next_fight)
    _add_button(controls, "RESTART", _restart)
    var picker := OptionButton.new()
    picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    for f in FIGHTERS: picker.add_item(f.name)
    picker.item_selected.connect(_select_fighter)
    controls.add_child(picker)

func _add_button(parent: Control, caption: String, callback: Callable) -> void:
    var b := Button.new()
    b.text = caption
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.pressed.connect(callback)
    parent.add_child(b)

func _select_fighter(index: int) -> void:
    selected = index
    var label := ui.find_child("EnemyLabel", true, false) as Label
    if label: label.text = FIGHTERS[selected].name.to_upper()
    _spawn_fighters()
    _say("Opponent selected: " + FIGHTERS[selected].name)

func _say(message: String) -> void:
    if status_label: status_label.text = message

func _refresh_ui() -> void:
    if player_bar: player_bar.value = player_hp
    if enemy_bar:
        enemy_bar.max_value = float(FIGHTERS[selected].hp)
        enemy_bar.value = enemy_hp
    if stamina_bar: stamina_bar.value = stamina

func _jab() -> void: _attack(7, 5, "Quick jab!")
func _hook() -> void: _attack(14, 12, "Heavy hook!")
func _uppercut() -> void: _attack(20, 18, "Rising Dragon uppercut!")
func _body() -> void: _attack(12, 10, "Heart Crusher body shot!")

func _attack(damage: float, cost: float, line: String) -> void:
    if round_over or busy: return
    if stamina < cost:
        _say("You're exhausted. Recover stamina.")
        return
    stamina -= cost
    busy = true
    var counter := enemy_windup
    if counter: damage *= 1.75
    enemy_hp = maxf(0, enemy_hp - damage)
    enemy_node.position.z += 0.45
    _say("PERFECT COUNTER! " + line if counter else line)
    _refresh_ui()
    await get_tree().create_timer(0.22).timeout
    if is_instance_valid(enemy_node): enemy_node.position.z -= 0.45
    busy = false
    if enemy_hp <= 0:
        round_over = true
        championship_wins += 1
        _say("KNOCKOUT! Tap FIGHT / NEXT for the next challenger.")

func _dodge(direction: int) -> void:
    if round_over: return
    dodging = true
    player_node.position.x = float(direction) * 0.75
    await get_tree().create_timer(0.42).timeout
    if is_instance_valid(player_node): player_node.position.x = 0
    dodging = false
    stamina = minf(100, stamina + 3)
    _refresh_ui()
    _say("Clean slip. Counterattack!")

func _duck() -> void:
    if round_over: return
    player_node.position.y = -2.65
    await get_tree().create_timer(0.45).timeout
    if is_instance_valid(player_node): player_node.position.y = -2.25
    _say("You duck under the punch.")

func _next_fight() -> void:
    if not round_over:
        _say("Win this bout before advancing.")
        return
    if selected == FIGHTERS.size() - 1:
        _say("WORLD CHAMPION! You conquered the World Tour.")
        return
    selected += 1
    var picker := ui.find_child("OptionButton", true, false) as OptionButton
    if picker: picker.select(selected)
    var label := ui.find_child("EnemyLabel", true, false) as Label
    if label: label.text = FIGHTERS[selected].name.to_upper()
    _spawn_fighters()
    _say("CHAMPIONSHIP ROUND " + str(selected + 1) + " — " + FIGHTERS[selected].name)

func _restart() -> void:
    _spawn_fighters()
    _say("Bout restarted. Fight!")

func _process(delta: float) -> void:
    stamina = minf(100, stamina + delta * 3.5)
    if not round_over:
        enemy_timer -= delta
        if enemy_timer <= 0 and not enemy_windup:
            enemy_windup = true
            _say(FIGHTERS[selected].name.to_upper() + " IS WINDING UP! DODGE OR BLOCK!")
            tell_timer = 0.85
        if enemy_windup:
            tell_timer -= delta
            if tell_timer <= 0:
                enemy_windup = false
                if not dodging and not blocking:
                    player_hp = maxf(0, player_hp - float(FIGHTERS[selected].power) * 13.0)
                    _say("HIT! You took a heavy punch.")
                    if player_hp <= 0:
                        round_over = true
                        _say("KNOCKDOWN! Tap RESTART to try again.")
                elif blocking:
                    player_hp = maxf(0, player_hp - 3.0)
                    blocking = false
                    _say("Guard absorbs most of the damage.")
                enemy_timer = rng.randf_range(1.4, 2.6)
    _refresh_ui()
