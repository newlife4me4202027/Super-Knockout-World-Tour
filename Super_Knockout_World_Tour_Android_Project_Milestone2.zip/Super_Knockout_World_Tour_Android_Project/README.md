# SUPER KNOCKOUT!! WORLD TOUR — Android-ready Godot project

## What is included
- Godot 4 project with a real-time 3D boxing ring and primitive-built 3D boxer models.
- Eight selectable original opponents with different health, power, and speed profiles.
- Fixed front-facing camera: player remains foreground, opponent remains background.
- Touchscreen buttons for jab, hook, uppercut, body shot, dodge, duck, block, and next fight.
- Championship progression across eight opponents.
- Health and stamina HUD, opponent attack telegraphs, counters, knockouts, and retry flow.
- Mobile-friendly Godot Compatibility renderer configuration.

## Open and run
1. Install Godot 4.2 or newer on a desktop computer.
2. Import this folder (`project.godot`) in Godot.
3. Open `scenes/Main.tscn` and press Play.
4. For Android, install Android Studio / Android SDK and export templates matching your Godot version.
5. In Godot, configure Android export (SDK/JDK paths), create an Android export preset, then export an APK or AAB.

## Controls
Touch buttons are included in the game UI. Desktop testing:
- A / Left Arrow: dodge left
- D / Right Arrow: dodge right
- S / Down Arrow: duck
- J: jab, K: hook, L: uppercut, I: body shot
- Space: guard (tap the on-screen BLOCK button on mobile)
- R is not bound in this project; use NEXT FIGHT to retry after a knockdown.

## Important status
This is an Android-ready source project, not a compiled APK. An Android SDK/export toolchain is not present in the creation environment, so no installable APK is claimed here. The current project is intentionally not padded to 100 MB with junk; its size should grow through production-quality character meshes, textures, animation, audio, and arena assets as those are authored.
